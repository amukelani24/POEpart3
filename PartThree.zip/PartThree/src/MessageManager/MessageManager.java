package MessageManager;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Student
 */

public class MessageManager extends parttwo.Message {

    private final Path jsonFile = Path.of("stored_messages.json");

    // Add a message to the shared message lists
    public void addMessage(String id, String hash, String sender,
            String recipient, String message, String status) {

        sentMessages.add(message);
        messageIdsList.add(id);
        messageIds.add(id);
        msgHash.add(hash);
        recipientNumber.add(recipient);
        senders.add(sender);
        messageStatus.add(status);

        if (status.equalsIgnoreCase("Sent")) {
            numMessageSent++;
        } else if (status.equalsIgnoreCase("Stored")) {
            storedMessages.add(message);
            saveStoredMessages();
        } else if (status.equalsIgnoreCase("Disregarded")
                || status.equalsIgnoreCase("Disregard")) {
            disregardedMessages.add(message);
        }
    }

    // Display stored messages
    public void showStoredMessages() {
        loadStoredMessages();

        boolean found = false;

        System.out.println("\n===== STORED MESSAGES =====");

        for (int i = 0; i < messageStatus.size(); i++) {
            if (messageStatus.get(i).equalsIgnoreCase("Stored")) {
                System.out.println("Message ID: " + messageIdsList.get(i));
                System.out.println("Sender: " + senders.get(i));
                System.out.println("Recipient: " + recipientNumber.get(i));
                System.out.println("Message: " + sentMessages.get(i));
                System.out.println("--------------------------");
                found = true;
            }
        }

        if (!found) {
            System.out.println("No stored messages.");
        }
    }

    // Display senders and recipients
    public void displaySendersAndRecipients() {
        for (int i = 0; i < messageIdsList.size(); i++) {
            System.out.println("Sender: " + senders.get(i));
            System.out.println("Recipient: " + recipientNumber.get(i));
            System.out.println();
        }
    }

    // Find the longest sent message
    public void findLongestMessage() {
        String longest = "";

        for (int i = 0; i < sentMessages.size(); i++) {
            if (messageStatus.get(i).equalsIgnoreCase("Sent")) {
                if (sentMessages.get(i).length() > longest.length()) {
                    longest = sentMessages.get(i);
                }
            }
        }

        if (longest.isEmpty()) {
            System.out.println("No sent messages to analyse.");
        } else {
            System.out.println("Longest message: " + longest);
        }
    }

   
    private String findMessageByID(String id) {
        int index = messageIdsList.indexOf(id);

        if (index == -1) {
            return null;
        }

        return sentMessages.get(index);
    }

    
    public void searchByRecipient(String recipient) {
        boolean found = false;

        for (int i = 0; i < recipientNumber.size(); i++) {
            if (recipientNumber.get(i).equals(recipient)) {
                System.out.println("Message ID: " + messageIdsList.get(i));
                System.out.println("Message: " + sentMessages.get(i));
                System.out.println("Status: " + messageStatus.get(i));
                System.out.println("--------------------------");
                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    // Delete a message using its hash
    public void deleteMessageByHash(String hash) {
        int index = msgHash.indexOf(hash);

        if (index == -1) {
            System.out.println("Message hash not found.");
            return;
        }

        String message = sentMessages.get(index);
        String id = messageIdsList.get(index);
        String status = messageStatus.get(index);

        sentMessages.remove(index);
        messageIdsList.remove(index);
        messageIds.remove(id);
        msgHash.remove(index);
        recipientNumber.remove(index);
        senders.remove(index);
        messageStatus.remove(index);

        storedMessages.remove(message);
        disregardedMessages.remove(message);

        if (status.equalsIgnoreCase("Sent")) {
            numMessageSent--;
        }

        saveStoredMessages();

        System.out.println("Message successfully deleted.");
    }

    // Display the full message report
    public void displayFullReport() {
        if (messageIdsList.isEmpty()) {
            System.out.println("No messages to display.");
            return;
        }

        System.out.println("\n========== FULL MESSAGE REPORT ==========");

        for (int i = 0; i < messageIdsList.size(); i++) {
            System.out.println("Message ID: " + messageIdsList.get(i));
            System.out.println("Message Hash: " + msgHash.get(i));
            System.out.println("Sender: " + senders.get(i));
            System.out.println("Recipient: " + recipientNumber.get(i));
            System.out.println("Message: " + sentMessages.get(i));
            System.out.println("Status: " + messageStatus.get(i));
            System.out.println("-----------------------------------------");
        }
    }

    // Save stored messages to JSON
    private void saveStoredMessages() {
        StringBuilder json = new StringBuilder("[\n");
        boolean first = true;

        for (int i = 0; i < messageStatus.size(); i++) {
            if (messageStatus.get(i).equalsIgnoreCase("Stored")) {

                if (!first) {
                    json.append(",\n");
                }

                json.append("  [")
                        .append(jsonString(messageIdsList.get(i))).append(",")
                        .append(jsonString(msgHash.get(i))).append(",")
                        .append(jsonString(senders.get(i))).append(",")
                        .append(jsonString(recipientNumber.get(i))).append(",")
                        .append(jsonString(sentMessages.get(i))).append(",")
                        .append(jsonString(messageStatus.get(i)))
                        .append("]");

                first = false;
            }
        }

        json.append("\n]\n");

        try {
            Files.writeString(jsonFile, json.toString());
        } catch (IOException e) {
            System.out.println("Could not save stored messages.");
        }
    }

    // Convert text into a JSON string
    private String jsonString(String text) {
        String escaped = text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");

        return "\"" + escaped + "\"";
    }

    // Read stored messages from JSON
    private void loadStoredMessages() {
        if (!Files.exists(jsonFile)) {
            return;
        }

        try {
            String json = Files.readString(jsonFile);

            Pattern pattern = Pattern.compile(
                    "\\[\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*,"
                    + "\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*,"
                    + "\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*,"
                    + "\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*,"
                    + "\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*,"
                    + "\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*\\]"
            );

            Matcher matcher = pattern.matcher(json);

            while (matcher.find()) {
                String id = unescapeJson(matcher.group(1));

                if (!messageIdsList.contains(id)) {
                    String hash = unescapeJson(matcher.group(2));
                    String sender = unescapeJson(matcher.group(3));
                    String recipient = unescapeJson(matcher.group(4));
                    String message = unescapeJson(matcher.group(5));
                    String status = unescapeJson(matcher.group(6));

                    addMessage(id, hash, sender, recipient, message, status);
                }
            }

        } catch (IOException e) {
            System.out.println("Could not read stored messages.");
        }
    }

    // Convert JSON text back into normal text
    private String unescapeJson(String text) {
        return text.replace("\\r", "\r")
                .replace("\\n", "\n")
                .replace("\\\"", "\"")
                .replace("\\\\", "\\");
    }

    // Getters
    public List<String> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public List<String> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }

    public List<String> getStoredMessages() {
        loadStoredMessages();
        return new ArrayList<>(storedMessages);
    }

    public List<String> getMessageHashes() {
        return new ArrayList<>(msgHash);
    }

    public List<String> getMessageIDs() {
        return new ArrayList<>(messageIdsList);
    }

    // Part 2 messaging functionality, extended for Part 3
    @Override
    public void sendingMessages() {
        System.out.print("How many messages do you want to send? ");

        if (!input.hasNextInt()) {
            System.out.println("Please enter a valid number.");
            input.nextLine();
            return;
        }

        int numberOfMessages = input.nextInt();
        input.nextLine();

        if (numberOfMessages <= 0) {
            System.out.println("Enter a number greater than zero.");
            return;
        }

        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println("\n===== MESSAGE " + i + " =====");

            String id = generateMessageID();

            System.out.print("Enter recipient number: ");
            String recipient = input.nextLine();

            if (!checkRecipientCell(recipient).equals("Valid number")) {
                System.out.println("Invalid recipient number.");
                i--;
                continue;
            }

            System.out.print("Enter your message: ");
            String message = input.nextLine();

            if (message.trim().isEmpty() || message.length() > 250) {
                System.out.println("Please enter a message of 1 to 250 characters.");
                i--;
                continue;
            }

            int messageNumber = messageIdsList.size() + 1;
            String hash = createMessageHash(id, messageNumber, message);

            System.out.print("Enter sender name: ");
            String sender = input.nextLine();

            System.out.println("\n1. Send message");
            System.out.println("2. Store message");
            System.out.println("3. Disregard message");
            System.out.print("Enter choice: ");

            String choice = input.nextLine();

            switch (choice) {
                case "1":
                    addMessage(id, hash, sender, recipient, message, "Sent");
                    System.out.println("Message successfully sent.");
                    break;

                case "2":
                    addMessage(id, hash, sender, recipient, message, "Stored");
                    System.out.println("Message successfully stored.");
                    break;

                case "3":
                    addMessage(id, hash, sender, recipient, message, "Disregarded");
                    System.out.println("Message disregarded.");
                    break;

                default:
                    System.out.println("Invalid choice. Message not added.");
                    i--;
                    break;
            }
        }

        System.out.println("\nTotal messages sent: " + returnTotalMessages());
    }
    
    public void searchMessageByID(String messageID) {

    boolean found = false;

    for (int i = 0; i < messageIdsList.size(); i++) {

        if (messageIdsList.get(i).equals(messageID)) {

            System.out.println("\n===== MESSAGE FOUND =====");

            System.out.println("Message ID: " + messageIdsList.get(i));

            System.out.println("Sender: " + senders.get(i));

            System.out.println("Recipient: " + recipientNumber.get(i));

            System.out.println("Message: " + sentMessages.get(i));

            System.out.println("Status: " + messageStatus.get(i));

            found = true;
            break;
        }
    }

    if (!found) {
        System.out.println("Message ID not found.");
    }
}
}