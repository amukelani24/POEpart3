/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package MessageManager;

import java.util.Scanner;
import parttwo.Registration;
import parttwo.Login;

/**
 *
 * @author Student
 */
public class PartThree {

/**
* @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);

        // PART 1: REGISTRATION
        Registration registration = new Registration();

        System.out.println("\n===== REGISTRATION =====");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter cellphone number: ");
        String cellphone = input.nextLine();

        String registrationResult = registration.registerUser(
                username, password, cellphone);

        System.out.println(registrationResult);

        if (!registration.registerStatus(username, password, cellphone)) {
            System.out.println("Please restart and register with valid details.");
            input.close();
            return;
        }

        // PART 1: LOGIN
        Login login = new Login(username, password);

        System.out.println("\n===== LOGIN =====");

        System.out.print("Enter username: ");
        String enteredUsername = input.nextLine();

        System.out.print("Enter password: ");
        String enteredPassword = input.nextLine();

        boolean loginSuccessful = login.loginUser(
                enteredUsername, enteredPassword);

        System.out.println(login.returnLoginStatus(loginSuccessful));

        if (!loginSuccessful) {
            System.out.println("Login failed. QuickChat cannot be accessed.");
            input.close();
            return;
        }

        MessageManager msg = new MessageManager();

        int choice;

        do {
            System.out.println("\n===== WELCOME TO QUICKCHAT =====");
            System.out.println("1. Send Messages");
            System.out.println("2. Stored Messages");
            System.out.println("3. Display Full Report");
            System.out.println("4. Delete Message by Hash");
            System.out.println("5. Search Message by ID");
            System.out.println("6. Quit");

            System.out.print("Choose an option: ");

            while (!input.hasNextInt()) {
                System.out.println("Please enter a number.");
                input.nextLine();
                System.out.print("Choose an option: ");
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:
                    msg.sendingMessages();
                    break;

                case 2:
                    msg.showStoredMessages();
                    break;

                case 3:
                    msg.displayFullReport();
                    break;

                case 4:
                    System.out.print("Enter the message hash to delete: ");
                    String hash = input.nextLine();
                    msg.deleteMessageByHash(hash);
                    break;
                    
                case 5:
                    System.out.println("Enter the Message ID to search: ");
                    break;

                case 6:
                    System.out.println("Thank you for using QuickChat!");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 6);

        input.close();
    }
}