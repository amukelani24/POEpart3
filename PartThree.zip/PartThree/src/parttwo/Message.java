/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parttwo;

import parttwo.Message;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Student
 */

public class Message {

    protected ArrayList<String> sentMessages = new ArrayList<>();
    protected ArrayList<String> messageIdsList = new ArrayList<>();
    protected HashSet<String> messageIds = new HashSet<>();
    protected ArrayList<String> msgHash = new ArrayList<>();
    protected ArrayList<String> recipientNumber = new ArrayList<>();
    protected ArrayList<String> messageStatus = new ArrayList<>();
    protected ArrayList<String> disregardedMessages = new ArrayList<>();
    protected ArrayList<String> storedMessages = new ArrayList<>();
    protected ArrayList<String> senders = new ArrayList<>();

    protected Random random = new Random();
    protected Scanner input = new Scanner(System.in);

    protected int numMessageSent = 0;

    public void sendingMessages() {

        System.out.print("How many messages do you want to send? ");

        int numberOfMessages = input.nextInt();
        input.nextLine();

        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println("\n==============================");
            System.out.println("MESSAGE " + i);
            System.out.println("==============================");

            String messageID = generateMessageID();

            if (!checkMessageID(messageID)) {
                System.out.println("Invalid Message ID.");
                i--;
                continue;
            }

            System.out.print("Enter recipient cell number: ");
            String recipient = input.nextLine();

            String recipientResult = checkRecipientCell(recipient);

            if (!recipientResult.equals("Valid number")) {
                System.out.println(recipientResult);
                i--;
                continue;
            }

            System.out.print("Enter your message: ");
            String messageText = input.nextLine();

            if (messageText.length() > 250 || messageText.trim().isEmpty()) {
                System.out.println("Please enter a message of 1 to 250 characters.");
                i--;
                continue;
            }

            int messageNumber = sentMessages.size() + 1;

            String messageHash = createMessageHash(
                    messageID, messageNumber, messageText);

            msgHash.add(messageHash);
            sentMessages.add(messageText);
            messageIdsList.add(messageID);
            messageIds.add(messageID);
            recipientNumber.add(recipient);

            System.out.print("Enter sender name: ");
            String sender = input.nextLine();
            senders.add(sender);

            String status = SentMessage();

            if (status.equals("Stored")) {
                messageStatus.add("Stored");
            } else {
                messageStatus.add(status);
            }
        }

        System.out.println(printMessages());

        System.out.println("Total messages sent: " + returnTotalMessages());
    }

    public int returnTotalMessages() {
        return numMessageSent;
    }

    public String createMessageHash(
            String messageID, int messageNumber, String messageText) {

        String firstTwoNumbers = messageID.substring(0, 2);

        String cleanMessage = messageText.trim();
        String[] words = cleanMessage.split("\\s+");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        return (firstTwoNumbers + ":" + messageNumber + ":"
                + firstWord + " " + lastWord).toUpperCase();
    }

    public String generateMessageID() {

        String messageID;

        do {
            long number = 1000000000L + random.nextLong(9000000000L);
            messageID = String.valueOf(number);

        } while (messageIds.contains(messageID));

        return messageID;
    }

    public boolean checkMessageID(String messageID) {
        return messageID != null && messageID.matches("[0-9]{10}");
    }

    public String checkRecipientCell(String cellphone) {

        if (cellphone.matches("^\\+27[0-9]{9}$")
                || cellphone.matches("^0[0-9]{9}$")) {

            return "Valid number";

        } else {
            return "Invalid number";
        }
    }

    public String SentMessage() {

        System.out.println("\nChoose what you want to do with this message!");
        System.out.println("1. Send");
        System.out.println("2. Disregard");
        System.out.println("3. Store");
        System.out.print("Enter your choice: ");

        int choice = input.nextInt();
        input.nextLine();

        switch (choice) {

            case 1 -> {
                System.out.println("Message successfully sent");
                numMessageSent++;
                return "Sent";
            }

            case 2 -> {
                int lastIndex = sentMessages.size() - 1;

                System.out.println("Message disregarded.");

                disregardedMessages.add(sentMessages.get(lastIndex));

                return "Disregarded";
            }

            case 3 -> {
                int lastIndex = sentMessages.size() - 1;

                storeMessage(lastIndex);

                System.out.println("Message successfully stored.");

                return "Stored";
            }

            default -> {
                System.out.println("Invalid option");
                return "Disregarded";
            }
        }
    }

    public String printMessages() {

        StringBuilder allMessages = new StringBuilder();

        for (int i = 0; i < sentMessages.size(); i++) {

            allMessages.append("Message ID: ")
                    .append(messageIdsList.get(i)).append("\n");

            allMessages.append("Message Hash: ")
                    .append(msgHash.get(i)).append("\n");

            allMessages.append("Recipient: ")
                    .append(recipientNumber.get(i)).append("\n");

            allMessages.append("Message: ")
                    .append(sentMessages.get(i)).append("\n");

            allMessages.append("Status: ")
                    .append(messageStatus.size() > i
                            ? messageStatus.get(i) : "Pending")
                    .append("\n");
        }

        return allMessages.toString();
    }

    public void storeMessage(int index) {

        String message = sentMessages.get(index);
        storedMessages.add(message);

        try (FileWriter writer = new FileWriter("stored_messages.json")) {

            writer.write("[\n");

            for (int i = 0; i < storedMessages.size(); i++) {

                String escapedMessage = storedMessages.get(i)
                        .replace("\\", "\\\\")
                        .replace("\"", "\\\"");

                writer.write("  \"" + escapedMessage + "\"");

                if (i < storedMessages.size() - 1) {
                    writer.write(",");
                }

                writer.write("\n");
            }

            writer.write("]\n");

            System.out.println("Message successfully stored in JSON file.");

        } catch (IOException e) {
            System.out.println("Error storing message.");
        }
    }
}


    

